import os,pickle
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
import faiss
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); DATA=BASE+"/data"; STORE=BASE+"/vector_store"
def chunks(text,size=800,overlap=150):
    text=" ".join(text.split()); out=[]; start=0
    while start<len(text):
        end=start+size; out.append(text[start:end])
        if end>=len(text): break
        start=end-overlap
    return out
records=[]
for fn in os.listdir(DATA):
    if fn.endswith(".pdf"):
        for page_no,page in enumerate(PdfReader(os.path.join(DATA,fn)).pages,1):
            for c in chunks(page.extract_text() or ""):
                if c.strip(): records.append({"text":c,"source":fn,"page":page_no})
print("Chunks:",len(records))
model=SentenceTransformer("all-MiniLM-L6-v2")
emb=model.encode([r["text"] for r in records],batch_size=32,normalize_embeddings=True,show_progress_bar=True)
index=faiss.IndexFlatIP(emb.shape[1]); index.add(emb)
faiss.write_index(index,STORE+"/index.faiss")
with open(STORE+"/metadata.pkl","wb") as f: pickle.dump(records,f)
print("Vector store created successfully.")
