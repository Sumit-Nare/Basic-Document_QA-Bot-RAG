import os,pickle,faiss
from sentence_transformers import SentenceTransformer
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); STORE=BASE+"/vector_store"
model=None
def retrieve(q,k=3):
    global model
    if model is None: model=SentenceTransformer("all-MiniLM-L6-v2")
    if not os.path.exists(STORE+"/index.faiss"): raise FileNotFoundError("Run: py src\\ingest.py first")
    index=faiss.read_index(STORE+"/index.faiss")
    with open(STORE+"/metadata.pkl","rb") as f: meta=pickle.load(f)
    qv=model.encode([q],normalize_embeddings=True); scores,ids=index.search(qv,min(k,len(meta)))
    return [(meta[i],float(s)) for s,i in zip(scores[0],ids[0]) if i>=0]
